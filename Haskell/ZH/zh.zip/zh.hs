module Zh where
import Data.List
import Data.Char

squareSum :: Num a => (a, a) -> (a, a, a)
squareSum (s1,s2) = (s1,s2,s1^2 + s2^2)

names :: [String] -> [String] -> [String]
names [] [] = []
names (x:xs) (y:ys) = [x ++ " " ++ y] ++ names xs ys

triangleArea :: (Double, Double, Double) -> Maybe Double
triangleArea (a,b,c)
    | c < (a+b) && a*a + b*b == c*c = Just ((a*b)/2)
    | otherwise = Nothing

doubleIdxs:: Eq a  => [(a,a)] -> Maybe [Int]
doubleIdxs xs
    | doubleIdxsHelp xs 1 == [] = Nothing
    | otherwise = Just (doubleIdxsHelp xs 1)

doubleIdxsHelp:: Eq a  => [(a,a)] -> Int -> [Int]
doubleIdxsHelp [] sz = []
doubleIdxsHelp ((a,b):xs) sz
    | a == b = sz : doubleIdxsHelp xs (sz+1)
    | otherwise = doubleIdxsHelp xs (sz+1)


snakeToCamel :: String -> String
snakeToCamel [] = []
snakeToCamel [x] = [x]
snakeToCamel (x:y:xs)
    | x == '_' && isDigit y = y : snakeToCamel xs
    | x == '_' = (toUpper y) : snakeToCamel xs
    | otherwise = x : snakeToCamel (y:xs)


removeExtremes :: Ord a => [a] -> [a]
removeExtremes xs = deleteBy (\x y -> x == y) (maximum xs) (removeHelp xs)

removeHelp :: Ord a => [a] -> [a]
removeHelp xs = deleteBy (\x y -> x == y) (minimum xs) xs

-- replaceLastOcc :: Eq a => a {-mit-} -> a {-mire-} -> [a] -> Maybe [a]
-- replaceLastOcc _ _ [] = []
-- replaceLastOcc mit mire (x:xs)
--     | x == mit = mire : xs
--     | otherwise = x : replaceLastOcc mit mire xs

anagram :: String -> String -> Bool
anagram xs ys = sort xs == sort ys

-- sumWithLenghtN :: Num a => Int -> [[a]] -> a
-- sumWithLenghtN n xs = sumWithLenghtNSzamlalo n xs 0


-- sumWithLenghtNSzamlalo :: Num a => Int -> [[a]] -> Int -> a
-- sumWithLenghtNSzamlalo _ [] sz = sz
-- sumWithLenghtNSzamlalo n (x:xs) sz
--     | length x == n = sumWithLenghtNSzamlalo n xs (sz + (sum x))
--     | otherwise = sumWithLenghtNSzamlalo n xs sz

isSteady :: Eq b => (a -> b) -> [a] -> Bool
isSteady f [] = True
isSteady f (x:y:xs)
    | length (x:y:xs) == 2 && f x == f y = True
    | f x == f y = isSteady f (y:xs)
    | otherwise = False

data Parcell
    = P String Double Int
    deriving (Eq,Show)
-- cím, súly, utánvét

deliveryFee :: Parcell -> Maybe Double
deliveryFee (P cim suly _)
    | cim =="Asgard" = Just (suly * 100)
    | cim =="Midgard" = Just (suly * 10)
    | cim =="Vanaheim" = Just (suly * 80)
    | cim =="Alfheim" = Just (suly * 50)
    | otherwise = Nothing

deliveryFeeHelp :: Parcell -> Double
deliveryFeeHelp (P cim suly _)
    | cim =="Asgard" = (suly * 100)
    | cim =="Midgard" =  (suly * 10)
    | cim =="Vanaheim" =  (suly * 80)
    | cim =="Alfheim" =  (suly * 50)
    | otherwise = 0

delivery :: [Parcell] -> Double
delivery [] = 0
delivery ((P cim suly utanvet):xs)
    | deliveryFeeHelp (P cim suly utanvet) /= 0 = ((deliveryFeeHelp (P cim suly utanvet)) + fromIntegral utanvet) + (delivery xs)
    | otherwise = delivery xs


-- indAndReplace :: String {- miben -} -> String {- mit -} -> String {- mire -} -> String
-- indAndReplace (x:xs) mit mire


shrinkText :: String -> String
shrinkText [] = []
shrinkText (x:xs)
    | x == '(' = shrinkText (drop 1 (dropWhile (\x -> x /= ')' ) xs))
    | otherwise = x :  shrinkText xs
