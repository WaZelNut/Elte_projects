#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void feladat(FILE *stream);
void reverse(char *array);
#endif
