#include "mufaj.h"

Termeszettudomanyos* Termeszettudomanyos::_instance=nullptr;
Ifjusagi* Ifjusagi::_instance=nullptr;
Szepirodalmi* Szepirodalmi::_instance=nullptr;