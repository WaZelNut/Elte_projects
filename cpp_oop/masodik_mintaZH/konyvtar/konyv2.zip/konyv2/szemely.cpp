#include "szemely.h"

void Szemely::Rogzit(Kolcson*k){
    kolcs.push_back(k);
}