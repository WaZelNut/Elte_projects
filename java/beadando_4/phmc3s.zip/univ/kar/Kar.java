package univ.kar;

public enum Kar {
    AJTK, BGGYK, BTK, GTK, IK, PPK, TOK, TATK, TTK;
}