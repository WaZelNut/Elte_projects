package restaurant.customer.types;

import restaurant.customer.Guest;

public class Minor extends Guest {
    public Minor(String name, int age) {
        this.name = name;
        this.age = age;
    }
}