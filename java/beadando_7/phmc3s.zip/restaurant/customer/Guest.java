package restaurant.customer;

public class Guest {
    protected String name;
    protected int age;


    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}